//Entrada:Usando un prompt se pide el resultado de la suma de 2 números generados de manera aleatoria.
//Salida:La página debe indicar si el resultado fue correcto o incorrecto, y el tiempo que tardó el usuario en escribir la respuesta.
//Alan Herrera Martínez A01412171
"use strict";

//Generar dos números aleatorios y pide al usuario que sume estos números.
function generarSuma(){
    let numero1 = Math.floor(Math.random() * 100) + 1;
    let numero2 = Math.floor(Math.random() * 100) + 1;
    return {numero1, numero2};
}

//Calcula el tiempo que tarda el usuario en responder
function medirTiempo(callback){
    let inicio = Date.now();
    let resultado = callback();
    let fin = Date.now();
    let tiempoRespuesta = (fin - inicio) / 1000;
    return {resultado, tiempoRespuesta};
}

// Verificar la respuesta del usuario.
function verificarRespuesta(num1, num2, respuestaUsuario, tiempo){
    let respuestaCorrecta = num1 + num2;
    if (respuestaUsuario === respuestaCorrecta){
        alert("¡Respuesta correcta! \nEl tiempo de respuesta fue: " + tiempo + " segundos.");
    } else{
        alert("Respuesta incorrecta. La suma es " + respuestaCorrecta + "\nEl tiempo de respuesta fue: " + tiempo + "segundos");
    }
}

// Ejecución del programa 
let { numero1, numero2} = generarSuma();
let { resultado, tiempoRespuesta} = medirTiempo(() => {
    let input = prompt(`¿Cuál es el resultado de la suma ${numero1} + ${numero2}?`);
    return parseInt(input);
});

if (!isNaN(resultado)){
    verificarRespuesta(numero1, numero2, resultado, tiempoRespuesta);
} else {
    alert("Debes ingresar un número válido.")
}