// Alan Herrera Martínez A01412171
"use strict";
//Clase que representa una cuenta bancaria con metodos para depositar y retirar dinero.
class CuentaBancaria {
    constructor(titular, RFC, saldo = 0) {
        this.titular = titular; // Nombre del titular de la cuenta
        this.RFC = RFC; // RFC del titular
        this.saldo = saldo; // Saldo inicial de la cuenta
    }
        // Metodo para depositar dinero en la cuenta
    depositar(cantidad) {
        if (cantidad > 0) {
            this.saldo += cantidad;
            console.log("Se han depositado: $" +cantidad+ " pesos en la cuenta.");
        } else {
            console.log("La cantidad a depositar debe ser mayor que cero.");
        }
    }
        // Metodo para retirar dinero de la cuenta
    retirar(cantidad) {
        if (cantidad > 0 && cantidad <= this.saldo) {
            this.saldo -= cantidad;
            console.log("Se han retirado: $" +cantidad+ "pesos de la cuenta.");
        } else {
            console.log("No se puede retirar la cantidad especificada. Fondos insuficientes o cantidad inválida.");
        }
    }

    imprimirInfo() {
        alert("Información de la cuenta:\n" + "Titular: " + this.titular + "\nRFC: " + this.RFC + "\nSaldo actual: $" + this.saldo);
    }
}
// creacion de una cuenta bancaria con saldo inicial
let cuenta = new CuentaBancaria("Alan Herrera Martínez", "XAXX010101000", 3000);
cuenta.imprimirInfo(); // Muestra la informacion inicial de la cuenta
// solicita al usuaio una accion: depositar o retirar
let opcion = prompt("¿Qué desea hacer? (depositar/retirar)");
if (opcion === "depositar") {
    let cantidad = parseFloat(prompt("Ingrese la cantidad a depositar:"));
    cuenta.depositar(cantidad); //Llamar al metodo para depositar 
} else if (opcion === "retirar") {
    let cantidad = parseFloat(prompt("Ingrese la cantidad a retirar:"));
    cuenta.retirar(cantidad); //Llamar al metodo para retirar
} else {
    console.log("Opción inválida.");// Muestra error si la opcion no es valida
}

cuenta.imprimirInfo(); //Muestra la informacion actualizada de la cuenta.
