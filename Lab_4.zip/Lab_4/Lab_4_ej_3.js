//Parámetros:Un arreglo de arreglos de números
//Regresa:Un arreglo con los promedios de cada uno de los renglones de la matriz.
//Alan Herrera Martínez A01412171
"use strict";
//Generar un número aleatorio entre min y max
function generarNumeroAleatorio(min, max){
    return Math.floor(Math.random()*(max - min + 1)) + min;
}

//Generara un Arreglo de números aleatorios
function generarArregloAleatorio(cantidad, min, max){
    return Array.from({ length: cantidad }, () => generarNumeroAleatorio(min, max));
}

//Cuenta negativos, ceros y positivos en un arreglo
function contarValores(arr){
    let resultado = arr.reduce((acumulador, valor) => {
        if (valor < 0){
            acumulador.negativos++;
        } else if (valor === 0){
            acumulador.ceros++;
        } else {
            acumulador.positivos++;
        }
        return acumulador;
    }, {negativos: 0, ceros: 0, positivos: 0});

    return resultado;
}

//Parámetros para generar el arreglo
const cantidad = 10;
const min = -1000;
const max = 1000;

//Generar el arreglo y cuenta de valores
let arreglo = generarArregloAleatorio(cantidad, min, max);
let conteo = contarValores(arreglo);

//Muestra el resultado
alert(`Arreglo aleatorio: ${arreglo}\nCantidad de números negativos: ${conteo.negativos}\nCantidad de ceros: ${conteo.ceros}\nCantidad de valores mayores a cero: ${conteo.positivos}`);
