//Alan Herrera Martínez A01412171
//Entrada:un número entero positivo solicitado al usuario mediante un prompt.
//Salida:Una tabla HTML que muestra los números del 1 al número ingresado, junto con sus respectivos cuadrados y cubos. La tabla se genera usando document.write().
"use strict";

function generarFila(numero){
    let fila = "<tr>";
    fila += "<td>" + numero + "</td>";
    fila += "<td>" + (numero * numero) + "</td>";
    fila += "<td>" + (numero * numero * numero) + "</td>";
    fila += "</tr>";
    return fila;
}
function generarTabla(num){
    document.write("<h2>Tabla de cuadrados y cubos hasta " + num + "</h2>");
    document.write("<table border='1'>");
    document.write("<tr><th>Número</th><th>Cuadrado</th><th>Cubo</th></tr>");

    for (let i = 1; i <= num; i++){
        document.write(generarFila(i));
    }
    document.write("</table>");
}
let input = prompt('Ingresa un número:');
let num = parseInt(input);

if (!isNaN(num) && num > 0){
    generarTabla(num);
} else if (input == null){
    alert('Has cancelado el ingreso');
} else{
    alert('Ingresa un número valido');
}
