// Función: promedios, Parámetros: Un arreglo de arreglos de números, Regresa: Un arreglo con los promedios de cada uno de los renglones de la matriz.
// Alan Herrera Martínez A01412171
"use strict";

function randomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomArray(cant, min, max) {
    let array = [];
    for (let i = 0; i < cant; i++) {
        array.push(randomNumber(min, max));
    }
    return array;
}

function randomMatrix(filas, columnas, min, max) {
    let matriz = [];
    for (let i = 0; i < filas; i++) {
        matriz.push(randomArray(columnas, min, max));
    }
    return matriz;
}

function promedios(matriz) {
    let promediosArray = [];

    for (let i = 0; i < matriz.length; i++) {
        let fila = matriz[i];
        let suma = 0;

        for (let j = 0; j < fila.length; j++) {
            suma += fila[j];
        }

        let promedio = suma / fila.length;
        promediosArray.push(promedio);
    }

    return promediosArray;
}

const filas = 3;
const columnas = 4;
let min = -100;
let max = 100;

let matriz = randomMatrix(filas, columnas, min, max);
let promediosResult = promedios(matriz);


let matrizFormateada = matriz.map(row => "|" + row.join(" | ") + " |").join("\n");

alert("Matriz aleatoria:\n" + matrizFormateada + "\n\nPromedios cada fila:\n" + promediosResult.join("\n"));
